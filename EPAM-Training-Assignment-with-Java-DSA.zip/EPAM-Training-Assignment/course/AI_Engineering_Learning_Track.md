# The 16-Topic AI Engineering Learning Track

The supplied course screenshot describes **16 core modules**:

1. **Python** — Data structures, APIs, testing.
2. **AI Foundations** — Model capabilities and limits.
3. **Prompt Evaluation** — Test prompt quality rigorously.
4. **AI Agents** — Goals, tools, and memory.
5. **Instruction Evals** — Score agent behavior.
6. **Context Engineering** — Right context at the right time.
7. **AI Fluency** — Daily coach and teammate.
8. **AI Orchestration** — Reliable flows and tool chains.
9. **A2A Communication** — Agent delegation and handoffs.
10. **MCP Protocol** — Connecting tools and data.
11. **Agent Harness** — Runtime, observer, and retry.
12. **Security** — Prompt injection and safe access.
13. **Guardrails** — Safety limits and checks.
14. **Token Optimization** — Cut cost and latency.
15. **Agentic Tools** — Frameworks for building.
16. **AI Agent Review** — Behavior, evals, and safety.

*Note: This file transcribes the topics visible in the screenshot. It is a course
outline, not proof of course completion.*
