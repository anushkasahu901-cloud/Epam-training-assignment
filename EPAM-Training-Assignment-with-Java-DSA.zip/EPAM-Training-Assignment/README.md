# EPAM Training Assignment – AI Engineering Learning Track

**Student:** Anushka Sahu  
**GitHub:** [anushkasahu901-cloud](https://github.com/anushkasahu901-cloud)

This repository contains a starter collection of Python examples and the 16-topic
AI Engineering Learning Track shown in the course screenshot.

## Learning track: 16 core modules

| No. | Module | Focus |
|---:|---|---|
| 01 | Python | Data structures, APIs, testing |
| 02 | AI Foundations | Model capabilities and limits |
| 03 | Prompt Evaluation | Test prompt quality rigorously |
| 04 | AI Agents | Goals, tools, and memory |
| 05 | Instruction Evals | Score agent behavior |
| 06 | Context Engineering | Right context at the right time |
| 07 | AI Fluency | Daily coach and teammate |
| 08 | AI Orchestration | Reliable flows and tool chains |
| 09 | A2A Communication | Agent delegation and handoffs |
| 10 | MCP Protocol | Connecting tools and data |
| 11 | Agent Harness | Runtime, observer, and retry |
| 12 | Security | Prompt injection and safe access |
| 13 | Guardrails | Safety limits and checks |
| 14 | Token Optimization | Cost and latency reduction |
| 15 | Agentic Tools | Frameworks for building |
| 16 | AI Agent Review | Behavior, evals, and safety |

## Repository contents

- `code/python_basics.py` – simple Python data structures and functions.
- `code/prompt_evaluation.py` – a small, rule-based prompt checklist example.
- `code/context_engineering.py` – demonstrates assembling relevant context.
- `code/java/` – beginner Java DSA programs: arrays, searching, sorting, and stack.
- `course/AI_Engineering_Learning_Track.md` – the course outline.

## Run the examples

Python 3.10 or newer is recommended. No third-party packages are required.

```bash
python code/python_basics.py
python code/prompt_evaluation.py
python code/context_engineering.py
```

## Java DSA practice

See [`code/java/README.md`](code/java/README.md) for Java examples and run instructions.

## Progress

This is a **starter learning repository**. The module list records the learning
track shown in the supplied screenshot; it does not claim that all modules or
certifications have been completed.
