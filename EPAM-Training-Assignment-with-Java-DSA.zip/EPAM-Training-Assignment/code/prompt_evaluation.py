"""A tiny rule-based prompt quality checklist.

This is a learning example, not an AI model or a complete evaluation system.
"""

CHECKS = {
    "has a clear task": lambda prompt: len(prompt.strip()) >= 10,
    "includes useful context": lambda prompt: any(
        word in prompt.lower() for word in ("context:", "background:", "given:")
    ),
    "specifies an output": lambda prompt: any(
        word in prompt.lower() for word in ("format:", "output:", "return:")
    ),
}


def evaluate_prompt(prompt):
    results = {name: check(prompt) for name, check in CHECKS.items()}
    score = sum(results.values())
    return score, results


if __name__ == "__main__":
    example = (
        "Explain binary search. Context: beginner student. "
        "Output: give steps and one example."
    )
    score, results = evaluate_prompt(example)
    print(f"Prompt score: {score}/{len(CHECKS)}")
    for check, passed in results.items():
        print(f"{'PASS' if passed else 'REVIEW'}: {check}")
