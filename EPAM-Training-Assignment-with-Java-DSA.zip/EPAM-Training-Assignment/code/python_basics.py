"""Beginner-friendly Python examples for the learning repository."""

def average(scores):
    """Return the average of a list of numbers."""
    if not scores:
        return 0
    return sum(scores) / len(scores)


def main():
    student = {
        "name": "Anushka",
        "course": "AI Engineering",
        "topics": ["Python", "AI Foundations", "Prompt Evaluation"],
    }

    print("Student:", student["name"])
    print("Course:", student["course"])
    print("Topics:")
    for topic in student["topics"]:
        print("-", topic)

    marks = [82, 90, 88]
    print("Average practice score:", average(marks))


if __name__ == "__main__":
    main()
