"""Simple demonstration of selecting relevant context for a task."""

NOTES = [
    {"topic": "Python", "text": "A list stores an ordered collection of items."},
    {"topic": "AI", "text": "An AI model can generate text from an input prompt."},
    {"topic": "DBMS", "text": "A primary key uniquely identifies a table row."},
]


def build_context(task, notes):
    """Return notes whose topic appears in the task description."""
    task_words = set(task.lower().split())
    return [
        note for note in notes
        if note["topic"].lower() in task_words
    ]


if __name__ == "__main__":
    task = "Help me revise Python concepts"
    selected = build_context(task, NOTES)

    print("Task:", task)
    print("Selected context:")
    for note in selected:
        print(f"- {note['topic']}: {note['text']}")
