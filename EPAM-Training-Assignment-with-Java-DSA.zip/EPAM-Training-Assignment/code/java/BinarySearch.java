public class BinarySearch {
    // Binary search requires the array to be sorted.
    static int search(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (arr[mid] == target) {
                return mid;
            } else if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] sorted = {3, 8, 12, 17, 21, 29, 35};
        int target = 21;
        System.out.println("Index: " + search(sorted, target));
    }
}
