# Java DSA Practice

Beginner-friendly Data Structures and Algorithms examples written in Java.

## Programs

| File | Topic | Time complexity |
|---|---|---|
| `ArrayBasics.java` | Array traversal, sum, maximum | O(n) |
| `LinearSearch.java` | Linear search | O(n) |
| `BinarySearch.java` | Binary search on a sorted array | O(log n) |
| `BubbleSort.java` | Bubble sort | O(n²) worst case |
| `StackUsingArray.java` | Stack: push, pop, peek | O(1) per operation |

## Run a program

Open a terminal in this folder and run:

```bash
javac BinarySearch.java
java BinarySearch
```

Replace `BinarySearch` with the class name of another program.

These are practice examples for learning; add your own notes and exercises as you progress.
