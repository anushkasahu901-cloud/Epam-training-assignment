public class LinearSearch {
    static int search(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] values = {10, 25, 30, 45, 50};
        int target = 30;
        int index = search(values, target);

        if (index == -1) {
            System.out.println(target + " was not found.");
        } else {
            System.out.println(target + " found at index " + index);
        }
    }
}
