import java.util.Arrays;

public class BubbleSort {
    static void sort(int[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            boolean swapped = false;

            for (int j = 0; j < arr.length - 1 - i; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
            }

            if (!swapped) {
                break; // The array is already sorted.
            }
        }
    }

    public static void main(String[] args) {
        int[] values = {64, 25, 12, 22, 11};
        sort(values);
        System.out.println("Sorted array: " + Arrays.toString(values));
    }
}
