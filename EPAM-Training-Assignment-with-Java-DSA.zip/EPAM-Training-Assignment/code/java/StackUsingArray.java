public class StackUsingArray {
    private final int[] data;
    private int top = -1;

    StackUsingArray(int capacity) {
        data = new int[capacity];
    }

    void push(int value) {
        if (top == data.length - 1) {
            System.out.println("Stack overflow");
            return;
        }
        data[++top] = value;
    }

    int pop() {
        if (top == -1) {
            System.out.println("Stack underflow");
            return -1;
        }
        return data[top--];
    }

    int peek() {
        if (top == -1) {
            return -1;
        }
        return data[top];
    }

    public static void main(String[] args) {
        StackUsingArray stack = new StackUsingArray(5);
        stack.push(10);
        stack.push(20);
        stack.push(30);

        System.out.println("Top element: " + stack.peek());
        System.out.println("Removed: " + stack.pop());
        System.out.println("New top: " + stack.peek());
    }
}
