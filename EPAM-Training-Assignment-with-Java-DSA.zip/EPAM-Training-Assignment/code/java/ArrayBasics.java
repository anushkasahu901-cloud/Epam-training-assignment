import java.util.Arrays;

public class ArrayBasics {
    public static void main(String[] args) {
        int[] numbers = {12, 5, 8, 20, 3};

        int sum = 0;
        int largest = numbers[0];

        for (int number : numbers) {
            sum += number;
            if (number > largest) {
                largest = number;
            }
        }

        System.out.println("Array: " + Arrays.toString(numbers));
        System.out.println("Sum: " + sum);
        System.out.println("Largest: " + largest);
    }
}
